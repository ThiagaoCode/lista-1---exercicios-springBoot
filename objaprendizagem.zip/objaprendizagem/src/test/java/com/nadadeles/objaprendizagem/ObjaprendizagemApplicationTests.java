package com.nadadeles.objaprendizagem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObjaprendizagemApplicationTests {

	@Test
	void contextLoads() {
	}

}
